package com.example.superkomponenty;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class CustomCircleView extends View {

    private Paint paint;
    private float radius = 100f;
    private float x = 250f;
    private float y = 250f;
    private int circleColor = Color.RED;

    public CustomCircleView(Context context) {
        super(context);
        init();
    }

    public CustomCircleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomCircleView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setupPaint();
    }

    private void setupPaint() {
        paint = new Paint();
        paint.setColor(circleColor);
        paint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawCircle(canvas);
    }

    private void drawCircle(Canvas canvas) {
        canvas.drawCircle(x, y, radius, paint);
    }

    public void changeCircleColor(int color) {
        setCircleColor(color);
        invalidate();
    }

    private void setCircleColor(int color) {
        this.circleColor = color;
        paint.setColor(circleColor);
    }

    public void changeCircleSize(float newRadius) {
        setRadius(newRadius);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            handleTouch(event);
            return true;
        }
        return false;
    }

    private void handleTouch(MotionEvent event) {
        int randomColor = getRandomColor();
        changeCircleColor(randomColor);

        animateCircle(event.getX(), event.getY());
        animateCircleSize();
    }

    private int getRandomColor() {
        return Color.rgb((int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255));
    }

    public void animateCircle(float newX, float newY) {
        animateProperty("x", newX);
        animateProperty("y", newY);
    }

    private void animateProperty(String propertyName, float value) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(this, propertyName, value);
        animator.setDuration(1000);
        animator.start();
    }

    public void animateCircleSize() {
        float newRadius = generateRandomRadius();
        animateProperty("radius", newRadius);
    }

    private float generateRandomRadius() {
        return 50f + (float)(Math.random() * 150f);
    }

    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
        invalidate();
    }
}

